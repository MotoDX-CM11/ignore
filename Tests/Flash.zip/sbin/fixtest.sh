#!/sbin/busybox sh
# Test
BBXS=/sbin/busybox

$BBXS umount /system
$BBXS umount /data
$BBXS umount /cache

$BBXS mv /dev/block/mmcblk1p21 /dev/block/mmcblk1p21-orig
